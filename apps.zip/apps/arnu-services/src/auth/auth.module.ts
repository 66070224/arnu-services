import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { AuthServiceService } from 'apps/auth-service/src/auth-service.service';
import { AuthServiceController } from 'apps/auth-service/src/auth-service.controller';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { UsersService } from 'apps/auth-service/src/users/users.service';

@Module({
  imports: [
    ClientsModule.registerAsync([
      {
        imports: [ConfigModule],
        name: 'AUTH_SERVICE',
        useFactory: (configService: ConfigService) => ({
          transport: Transport.TCP,
          options: {
            port: configService.get('AUTH_PORT') ?? 4001,
          },
        }),
        inject: [ConfigService],
      },
    ]),
  ],
  providers: [AuthService, AuthServiceService],
  controllers: [AuthController, AuthServiceController],
})
export class AuthModule {}
