import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from 'apps/auth-service/src/users/users.module';
import { AuthServiceModule } from 'apps/auth-service/src/auth-service.module';

@Module({
  imports: [
    ClientsModule.registerAsync([
      {
        imports: [ConfigModule],
        name: 'PROFILE_SERVICE',
        useFactory: (configService: ConfigService) => ({
          transport: Transport.TCP,
          options: {
            port: configService.get('PROFILE_PORT') ?? 4002,
          },
        }),
        inject: [ConfigService],
      },
      {
        imports: [ConfigModule],
        name: 'COMIC_SERVICE',
        useFactory: (configService: ConfigService) => ({
          transport: Transport.TCP,
          options: {
            port: configService.get('COMIC_PORT') ?? 4003,
          },
        }),
        inject: [ConfigService],
      },
    ]),
    AuthModule,
    AuthServiceModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
